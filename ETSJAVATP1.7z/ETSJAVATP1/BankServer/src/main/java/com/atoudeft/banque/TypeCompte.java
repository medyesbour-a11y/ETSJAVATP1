package com.atoudeft.banque;

import java.io.Serializable;

public enum TypeCompte implements Serializable {
    CHEQUE,
    EPARGNE
}
