package com.atoudeft.banque;

import java.io.Serializable;

public enum TypeOperation implements Serializable {
    DEPOT,
    RETRAIT,
    FACTURE,
    TRANSFER
}
